# BOOKIN - Website quản lý thư viện

## Cấu trúc thư mục
- index.html: Trang chủ
- books.html: Danh sách sách + tìm kiếm + lọc
- book-detail.html: Chi tiết sách
- style.css: CSS giao diện
- script.js: Dữ liệu mẫu và chức năng JavaScript

## Chức năng đã có
1. Cấu trúc thư mục dự án
2. Trang chủ
3. Header + Menu
4. Footer
5. Trang danh sách sách
6. Trang chi tiết sách
7. Dữ liệu sách mẫu
8. Hiển thị sách bằng JavaScript
9. Tìm kiếm theo tên/tác giả/thể loại
10. Lọc theo thể loại
11. Lọc và hiển thị trạng thái Còn sách/Đang mượn
12. Thông báo khi không tìm thấy sách
13. CSS đồng bộ giao diện Bookin
14. Responsive cho máy tính bảng và điện thoại

## Chạy
Mở `index.html` bằng trình duyệt. Không cần cài server cho phiên bản demo này.
